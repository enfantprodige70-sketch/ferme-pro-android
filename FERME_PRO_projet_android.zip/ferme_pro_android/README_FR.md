# FERME PRO — Projet Android de démarrage

## Ce que contient cette version
- Un projet Android natif minimal qui ouvre le prototype FERME PRO dans une WebView.
- Le prototype est inclus dans `app/src/main/assets/ferme_pro_demo.html`.
- Les données de démonstration restent enregistrées localement sur le téléphone via le stockage du navigateur intégré.

## Important — limites actuelles
Cette version est un **prototype hors ligne**. Elle ne comprend pas encore :
- l'inscription par SMS et les codes OTP ;
- un serveur / compte utilisateur ;
- la sauvegarde cloud et la synchronisation entre appareils ;
- les paiements ou abonnements.

Ces éléments nécessitent un backend, un fournisseur SMS et des tests de sécurité avant une diffusion publique.

## Construire l'APK depuis un téléphone
Le dépôt inclut une action GitHub (`.github/workflows/build-apk.yml`) qui compile l'APK dans le cloud.

1. Crée un compte GitHub si tu n'en as pas.
2. Crée un nouveau dépôt nommé `ferme-pro-android`.
3. Depuis ton navigateur Android, téléverse tous les fichiers et dossiers de ce projet dans le dépôt.
4. Ouvre l'onglet **Actions**, sélectionne **Build FERME PRO APK**, puis **Run workflow**.
5. Quand l'exécution est terminée, ouvre-la et télécharge l'artefact **FERME-PRO-debug-APK**.
6. Décompresse l'archive téléchargée pour obtenir `app-debug.apk`, puis installe-le sur ton téléphone.

GitHub peut demander d'autoriser les actions lors de la première utilisation.

## Développement
- Application ID : `com.fermepro.app`
- Minimum Android : Android 6.0 (API 23)
- Compile SDK : 35
- Java : 17
